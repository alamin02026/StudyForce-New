# Study Force (Android)

Offline study-focus app. Block apps on a timer, night lock, uninstall protection, weekly report card.
Developer: Al Amin, Student of Chattogram Polytechnic Institute.

## Build the APK (on your laptop)
1. Install Android Studio (free) from developer.android.com/studio.
2. Unzip this project. In Android Studio: File > Open > choose the `StudyForce` folder.
3. Wait for "Gradle sync" to finish (needs internet the first time).
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. Send `app-debug.apk` to the phone and install it.

If the build shows red errors, copy the first error message and send it to Claude to fix.

## First run on the phone
Open the app and tap Enable on each step in "Finish setup".
On Android 13 or newer, a sideloaded app is blocked from Accessibility and Notification access until you do:
Settings > Apps > Study Force > three dots (top right) > Allow restricted settings.
On Xiaomi, Oppo, Vivo, Realme also allow "Autostart" and set battery to "No restrictions", or the phone may stop the blocker.

## Replace the logo
- App icon: in Android Studio, right-click `res` > New > Image Asset > pick your logo file.
- Logo inside the app: replace `res/drawable/ic_logo.xml` with your own image
  (for a PNG, add `ic_logo.png` to `res/drawable` and delete `ic_logo.xml`).

## Change the admin password
Run on your computer (replace NEWPASSWORD):

    printf '%s' 'StudyForce::v1::NEWPASSWORD' | sha256sum

Paste the 64 characters into `HASH` in `Security.kt`, then rebuild. The password itself is never stored in the app.

## Screens
Welcome (first launch only), Home (timer dial), Apps to block, Night lock, Weekly report, Settings (permissions, protection, admin password note), How it works, About (developer, privacy policy, WhatsApp contact).

## What it does
- Pick any installed app to block; timer can only be extended, never shortened
- Ending early: choose a reason, wait 10 minutes, then confirm
- Study 60 min = 10 min earned break time
- Night lock: student sets start and end time; blocks everything except calls and messages
- Blocked apps cannot open and their notifications are hidden
- Social websites blocked in common browsers during focus (best effort)
- Uninstall / deactivate / force-stop screens ask for the admin password
- Emergency unlock with the admin password works on every phone
- Weekly report card image to share
- No internet permission. All data stays on the phone.

## Clock protection
Timers follow the phone's uptime clock, so changing the phone's date or time does not shorten a session.
After a phone restart the app trusts the phone clock again.

## Known limits
- Safe Mode and factory reset can bypass any app like this.
- Phone makers (Xiaomi, Oppo, Vivo, Samsung) use different Settings screens; the uninstall guard
  is tested on stock Android logic only and may miss some screens.
- Website blocking reads the browser address bar and may not work in every browser.
- Play Store requires a written reason for Accessibility and Device Admin use. Share the APK directly first.
