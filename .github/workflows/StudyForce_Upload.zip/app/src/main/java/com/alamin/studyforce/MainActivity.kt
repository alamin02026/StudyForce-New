package com.alamin.studyforce

import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

class MainActivity : Screen() {
    private val h = Handler(Looper.getMainLooper())
    private var dial: DialView? = null
    private var waitTv: TextView? = null
    private var selected = 60
    private var waitDone = false
    private val waitMs = 10 * 60_000L

    private val tick = object : Runnable {
        override fun run() {
            val st = Store(this@MainActivity)
            val t = st.now()
            val rem = st.sessionEnd - t
            if (st.sessionStart > 0 && rem <= 0) {
                st.finalizeIfDone()
                redraw()
                return
            }
            val total = maxOf(1L, st.sessionEnd - st.sessionStart)
            dial?.set(
                rem.toFloat() / total,
                if (st.onBreak(t)) "On a break" else "Focus time left",
                fmtDur(rem),
                "ends at ${fmtClock(st.sessionEnd)}"
            )
            if (st.endRequestAt > 0) {
                val left = waitMs - (t - st.endRequestAt)
                if (left <= 0 && !waitDone) {
                    redraw()
                    return
                }
                waitTv?.text = "You can end this session in ${fmtDur(left)}"
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    override fun render() {
        val st = Store(this)
        st.finalizeIfDone()
        val t = st.now()
        waitDone = st.endRequestAt > 0 && t - st.endRequestAt >= waitMs
        dial = null
        waitTv = null
        h.removeCallbacks(tick)

        // brand
        val brand = LinearLayout(this)
        brand.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        brand.addView(logo, LinearLayout.LayoutParams(dp(36), dp(36)))
        val name = tv("Study Force", 20f, C.TEXT, true)
        name.setPadding(dp(10), 0, 0, 0)
        brand.addView(name)
        root.addView(brand)

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = if (hour < 12) "Good morning" else if (hour < 17) "Good afternoon" else "Good evening"
        val running = st.sessionActive(t)
        root.put(tv(greet, 15f, C.MUTED), 20)
        root.put(tv(if (running) "Stay focused." else "Ready to study?", 32f, C.TEXT, true), 2)

        if (!Perms.all(this)) {
            val banner = box()
            banner.put(tv("Setup is not finished", 16f, C.YELLOW, true), 0)
            banner.put(tv("Turn on the permissions so blocking can work.", 13f, C.MUTED), 2)
            banner.put(btn("Open Settings", true, 14f) {
                startActivity(Intent(this, SettingsActivity::class.java))
            }, 10)
            root.put(banner, 16)
        }

        if (st.nightActive(t)) {
            root.put(
                tv("Night lock is active until ${fmtClock(st.nightWindowEnd(t))}.", 14f, C.YELLOW, true), 14
            )
        }

        // the round timer
        val d = DialView(this)
        dial = d
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(18)
        root.addView(d, lp)

        if (running) {
            val total = maxOf(1L, st.sessionEnd - st.sessionStart)
            d.set(
                (st.sessionEnd - t).toFloat() / total,
                if (st.onBreak(t)) "On a break" else "Focus time left",
                fmtDur(st.sessionEnd - t),
                "ends at ${fmtClock(st.sessionEnd)}"
            )
            activeSession(st, t)
        } else {
            d.set(selected / 180f, "Focus time", fmtDur(selected * 60_000L), "pick a time below")
            idleSession(st)
        }

        // numbers
        root.put(
            hrowN(
                statTile(fmtMins(st.studyOn(0)), "Studied today"),
                statTile("${st.streak()}", "Day streak"),
                statTile("${st.earned}m", "Break earned")
            ), 22
        )
        root.put(
            tv(
                "Study 60 minutes to earn 10 minutes of break time. " +
                    "Blocked attempts today: ${st.attemptsOn(0)}.",
                12f, C.MUTED
            ), 8
        )

        // menu
        root.put(
            hrowN(
                navTile(R.drawable.ic_apps, "Apps to block (${st.blocked.size})") {
                    startActivity(Intent(this, AppsActivity::class.java))
                },
                navTile(R.drawable.ic_moon, "Night lock") {
                    startActivity(Intent(this, NightActivity::class.java))
                }
            ), 20
        )
        root.put(
            hrowN(
                navTile(R.drawable.ic_chart, "Weekly report") {
                    startActivity(Intent(this, ReportActivity::class.java))
                },
                navTile(R.drawable.ic_settings, "Settings") {
                    startActivity(Intent(this, SettingsActivity::class.java))
                }
            ), 10
        )
        root.put(
            hrowN(
                navTile(R.drawable.ic_help, "How it works") {
                    startActivity(Intent(this, HelpActivity::class.java))
                },
                navTile(R.drawable.ic_info, "About") {
                    startActivity(Intent(this, AboutActivity::class.java))
                }
            ), 10
        )
    }

    // ---- first-time setup ----
    private fun grace() {
        val st = Store(this)
        st.protectOffUntil = st.now() + 5 * 60_000L
    }

    private fun setupRow(card: LinearLayout, title: String, why: String, done: Boolean, action: () -> Unit) {
        if (done) {
            card.put(tv("✓  $title", 15f, C.MUTED), 10)
        } else {
            card.put(tv(title, 16f, C.TEXT, true), 14)
            card.put(tv(why, 13f, C.MUTED), 2)
            card.put(btn("Enable", true, 15f) { grace(); action() }, 8)
        }
    }

    private fun setupCard() {
        val card = box()
        card.put(tv("Finish setup", 18f, C.YELLOW, true), 0)
        card.put(
            tv(
                "Study Force needs these to work. On Android 13 or newer, if a switch is greyed out: " +
                    "open Settings > Apps > Study Force > menu (three dots) > Allow restricted settings.",
                13f, C.MUTED
            ), 4
        )
        setupRow(card, "1. Show over other apps", "So the lock screen can appear on top of a blocked app.", Perms.overlay(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        setupRow(card, "2. Notification access", "So notifications from blocked apps can be hidden.", Perms.notifications(this)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        setupRow(card, "3. Device admin", "So Study Force cannot be uninstalled without the password.", Perms.admin(this)) {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            i.putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Stops Study Force from being removed during your study time."
            )
            startActivity(i)
        }
        setupRow(card, "4. Accessibility service", "So Study Force can see which app is open and block it.", Perms.accessibility(this)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.put(card, 20)
    }

    // ---- no session running ----
    private fun idleSession(st: Store) {
        val options = listOf(15 to "15m", 30 to "30m", 60 to "1h", 120 to "2h")
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for ((mins, label) in options) {
            val b = btn(label, selected == mins, 14f) {
                selected = mins
                redraw()
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.rightMargin = dp(6)
            chips.addView(b, lp)
        }
        val custom = btn("Custom", options.none { it.first == selected }, 14f) { askCustom() }
        chips.addView(custom, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.put(chips, 16)

        root.put(btn("Start focus") {
            if (!Perms.accessibility(this)) {
                toast("Turn on the Study Force accessibility service first.")
                return@btn
            }
            if (st.blocked.isEmpty()) {
                toast("Choose the apps to block first.")
                return@btn
            }
            if (selected > 180) {
                AlertDialog.Builder(this)
                    .setTitle("Long session")
                    .setMessage("Your phone will stay locked for ${fmtMins(selected)}. Continue?")
                    .setPositiveButton("Start") { _, _ -> begin(st) }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                begin(st)
            }
        }, 12)
    }

    private fun begin(st: Store) {
        st.startSession(selected)
        redraw()
    }

    private fun askCustom() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.hint = "Minutes (1 to 960)"
        AlertDialog.Builder(this)
            .setTitle("Custom time")
            .setView(et)
            .setPositiveButton("Set") { _, _ ->
                val v = et.text.toString().toIntOrNull()
                if (v != null && v in 1..960) {
                    selected = v
                    redraw()
                } else {
                    toast("Enter a number from 1 to 960.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- session running ----
    private fun activeSession(st: Store, t: Long) {
        root.put(
            hrow(
                btn("+15 min", false) { st.extend(15); redraw() },
                btn("+30 min", false) { st.extend(30); redraw() }
            ), 16
        )
        root.put(tv("Time can be added, but not taken away.", 12f, C.MUTED), 6)

        if (st.onBreak(t)) {
            root.put(tv("Break until ${fmtClock(st.breakUntil)}. Study time is not counted during a break.", 13f, C.MUTED), 8)
        }
        if (st.earned >= 10 && !st.onBreak(t)) {
            root.put(btn("Take a 10-min break (uses 10 earned min)", false) {
                st.takeBreak()
                redraw()
            }, 10)
        }

        // ending early: pick a reason, wait 10 minutes, then confirm
        if (st.endRequestAt == 0L) {
            root.put(btn("End early (10 min wait)", false) { askReason(st) }, 10)
        } else if (!waitDone) {
            waitTv = tv("You can end this session in ${fmtDur(waitMs - (t - st.endRequestAt))}", 14f, C.MUTED)
            root.put(waitTv!!, 14)
            root.put(btn("Cancel ending", false) { st.endRequestAt = 0L; redraw() }, 8)
        } else {
            root.put(btn("End session now") { st.endSession(); redraw() }, 14)
            root.put(btn("Keep studying", false) { st.endRequestAt = 0L; redraw() }, 8)
        }

        root.put(btn("Emergency unlock (admin password)", false) {
            startActivity(Intent(this, PasswordGateActivity::class.java).putExtra("purpose", "UNLOCK"))
        }, 10)

        h.postDelayed(tick, 1000)
    }

    private fun askReason(st: Store) {
        AlertDialog.Builder(this)
            .setTitle("Why do you want to stop?")
            .setItems(
                arrayOf(
                    "I finished studying",
                    "I need my phone for something important",
                    "Emergency",
                    "Other"
                )
            ) { _, _ ->
                st.endRequestAt = st.now()
                redraw()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
