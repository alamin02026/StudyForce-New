package com.alamin.studyforce

import android.content.Context
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Everything is saved on the phone. The app has no internet permission. */
class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("study_force", Context.MODE_PRIVATE)

    private inner class LongPref(val key: String) : ReadWriteProperty<Any?, Long> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Long = sp.getLong(key, 0L)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
            sp.edit().putLong(key, value).apply()
        }
    }

    private inner class IntPref(val key: String, val def: Int = 0) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(key, value).apply()
        }
    }

    private inner class BoolPref(val key: String, val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(key, value).apply()
        }
    }

    // ---- blocked apps ----
    var blocked: Set<String>
        get() = HashSet(sp.getStringSet("blocked", emptySet()) ?: emptySet())
        set(v) { sp.edit().putStringSet("blocked", HashSet(v)).apply() }

    var blockSites by BoolPref("blockSites", true)
    var welcomed by BoolPref("welcomed", false)

    // ---- focus session ----
    var sessionStart by LongPref("sStart")
    var sessionEnd by LongPref("sEnd")
    var endRequestAt by LongPref("endReq")
    var breakUntil by LongPref("breakUntil")
    var breakTotal by LongPref("breakTotal")
    var earned by IntPref("earned")          // minutes of break time earned

    // ---- night lock ----
    var nightOn by BoolPref("nightOn", false)
    var nightStart by IntPref("nightStart", 22 * 60)
    var nightEnd by IntPref("nightEnd", 6 * 60)
    var nightPausedUntil by LongPref("nightPaused")

    // ---- password gate ----
    var protectOffUntil by LongPref("protectOff")
    var failCount by IntPref("fails")
    var lockoutUntil by LongPref("lockout")

    var anchorWall by LongPref("aWall")
    var anchorElapsed by LongPref("aElapsed")

    /**
     * Trusted time. It follows the phone's uptime clock, so changing the phone's date or time
     * does not shorten a session or switch off the night lock. Small corrections (under 2 minutes,
     * for example a network time sync) are accepted. After a restart it starts again from the phone clock.
     */
    fun now(): Long {
        val e = SystemClock.elapsedRealtime()
        val wall = System.currentTimeMillis()
        if (anchorWall == 0L || e < anchorElapsed) {
            anchorWall = wall
            anchorElapsed = e
            return wall
        }
        val computed = anchorWall + (e - anchorElapsed)
        val diff = Math.abs(wall - computed)
        if (diff <= 5_000L) return computed
        if (diff < 120_000L) {
            anchorWall = wall
            anchorElapsed = e
            return wall
        }
        return computed
    }

    fun sessionActive(t: Long = now()) = sessionEnd > t
    fun onBreak(t: Long = now()) = t < breakUntil

    fun startSession(minutes: Int) {
        endSession()
        val t = now()
        sessionStart = t
        sessionEnd = t + minutes * 60_000L
        endRequestAt = 0L
        breakUntil = 0L
        breakTotal = 0L
    }

    /** Time can only be added, never removed. */
    fun extend(minutes: Int) {
        if (sessionActive()) sessionEnd += minutes * 60_000L
    }

    /** Spend 10 earned minutes to pause blocking for 10 minutes. */
    fun takeBreak() {
        if (sessionActive() && earned >= 10 && !onBreak()) {
            earned -= 10
            breakUntil = now() + 10 * 60_000L
            breakTotal += 10 * 60_000L
        }
    }

    fun finalizeIfDone() {
        if (sessionStart > 0 && sessionEnd <= now()) endSession()
    }

    /** Ends the session and credits the study time. 60 min of study earns 10 min of break time. */
    fun endSession() {
        if (sessionStart <= 0) return
        val end = minOf(now(), sessionEnd)
        val studyMs = maxOf(0L, end - sessionStart - breakTotal)
        val mins = (studyMs / 60_000L).toInt()
        addStudy(mins, end)
        earned += mins / 6
        sessionStart = 0L
        sessionEnd = 0L
        endRequestAt = 0L
        breakUntil = 0L
        breakTotal = 0L
    }

    // ---- night lock helpers ----
    private fun minuteOfDay(t: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    fun nightActive(t: Long = now()): Boolean {
        if (!nightOn || t < nightPausedUntil || nightStart == nightEnd) return false
        val m = minuteOfDay(t)
        return if (nightStart < nightEnd) m in nightStart until nightEnd
        else (m >= nightStart || m < nightEnd)
    }

    fun nightWindowEnd(t: Long = now()): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.HOUR_OF_DAY, nightEnd / 60)
        c.set(Calendar.MINUTE, nightEnd % 60)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= t) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** Admin password accepted: end the session and skip the rest of tonight's lock. */
    fun emergencyUnlock() {
        endSession()
        if (nightActive()) nightPausedUntil = nightWindowEnd()
        failCount = 0
    }

    // ---- wrong password limit ----
    fun lockedOut() = now() < lockoutUntil

    fun registerFail() {
        failCount += 1
        if (failCount >= 5) {
            lockoutUntil = now() + 30 * 60_000L
            failCount = 0
        }
    }

    // ---- daily stats ----
    private fun key(t: Long) = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(t))
    private fun dayTime(daysAgo: Int) = now() - daysAgo * 86_400_000L

    private fun addStudy(mins: Int, t: Long) {
        if (mins <= 0) return
        val k = "st_" + key(t)
        sp.edit().putInt(k, sp.getInt(k, 0) + mins).apply()
    }

    fun addAttempt() {
        val k = "at_" + key(now())
        sp.edit().putInt(k, sp.getInt(k, 0) + 1).apply()
    }

    fun studyOn(daysAgo: Int): Int = sp.getInt("st_" + key(dayTime(daysAgo)), 0)
    fun attemptsOn(daysAgo: Int): Int = sp.getInt("at_" + key(dayTime(daysAgo)), 0)

    /** How many days in a row the student studied (today counts once they have studied). */
    fun streak(): Int {
        var n = 0
        var d = if (studyOn(0) > 0) 0 else 1
        while (d < 400 && studyOn(d) > 0) {
            n++
            d++
        }
        return n
    }
}
