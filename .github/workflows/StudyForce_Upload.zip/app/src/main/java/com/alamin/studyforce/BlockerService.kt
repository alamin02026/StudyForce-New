package com.alamin.studyforce

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * The engine. It sees which app comes to the screen and:
 *  1. blocks apps chosen for focus time, and everything except calls during the night lock
 *  2. blocks social websites in browsers during focus time
 *  3. asks for the admin password if someone opens a screen about Study Force in Settings,
 *     the package installer or the Play Store (uninstall / deactivate / force stop)
 */
class BlockerService : AccessibilityService() {
    private var store: Store? = null
    private var allowed: Set<String> = emptySet()
    private var allowedAt = 0L
    private var lastBlockAt = 0L
    private var lastScanAt = 0L
    private var lastGateAt = 0L

    private fun st(): Store {
        val s = store ?: Store(this)
        store = s
        return s
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = Store(this)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return

        val t = st().now()
        val isContent = e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        val isBrowser = pkg in BROWSERS
        val isGuarded = pkg in GUARDED
        if (isContent && !isBrowser && !isGuarded) return
        if (isContent && t - lastScanAt < 400) return
        lastScanAt = t

        val s = st()
        s.finalizeIfDone()

        if (isGuarded && guard(pkg)) return

        if (allowed.isEmpty() || t - allowedAt > 60_000) {
            allowed = Policy.allowedPackages(this)
            allowedAt = t
        }

        if (Policy.isBlockedNow(s, pkg, allowed, t)) {
            block(pkg, if (s.nightActive(t)) "night" else "focus")
            return
        }

        if (isBrowser && s.blockSites && s.sessionActive(t) && !s.onBreak(t) && siteBlocked(pkg)) {
            block(pkg, "focus")
        }
    }

    // ---- blocking ----
    private fun block(pkg: String, mode: String) {
        val t = st().now()
        performGlobalAction(GLOBAL_ACTION_HOME)
        if (t - lastBlockAt < 1500) return
        lastBlockAt = t
        st().addAttempt()
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg
        }
        val i = Intent(this, LockActivity::class.java)
        i.putExtra("label", label)
        i.putExtra("mode", mode)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(i)
    }

    // ---- uninstall / deactivate protection ----
    private fun guard(pkg: String): Boolean {
        val t = st().now()
        if (t < st().protectOffUntil) return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val hit = try {
            root.findAccessibilityNodeInfosByText("Study Force")?.isNotEmpty() == true
        } catch (_: Exception) {
            false
        }
        if (!hit) return false
        performGlobalAction(GLOBAL_ACTION_HOME)
        if (t - lastGateAt < 1500) return true
        lastGateAt = t
        val i = Intent(this, PasswordGateActivity::class.java)
        i.putExtra("purpose", "UNINSTALL")
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }

    // ---- website blocking (best effort: reads the address bar of common browsers) ----
    private fun siteBlocked(pkg: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        for (id in URL_IDS) {
            val found = try {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")
            } catch (_: Exception) {
                null
            }
            if (found == null) continue
            for (n in found) {
                val txt = n.text?.toString() ?: continue
                if (hostBlocked(txt)) return true
            }
        }
        return false
    }

    private fun hostBlocked(raw: String): Boolean {
        var s = raw.trim().lowercase()
        s = s.removePrefix("https://").removePrefix("http://")
        val host = s.substringBefore('/').substringBefore('?').substringBefore(':')
        return SITES.any { host == it || host.endsWith(".$it") }
    }

    companion object {
        val BROWSERS = setOf(
            "com.android.chrome", "org.mozilla.firefox", "org.mozilla.firefox_beta",
            "com.brave.browser", "com.microsoft.emmx", "com.opera.browser",
            "com.opera.mini.native", "com.sec.android.app.sbrowser", "com.UCMobile.intl",
            "com.android.browser", "com.mi.globalbrowser", "com.kiwibrowser.browser",
            "com.duckduckgo.mobile.android"
        )

        /** Screens where someone could uninstall, deactivate or force-stop Study Force. */
        val GUARDED = setOf(
            "com.android.settings", "com.android.packageinstaller",
            "com.google.android.packageinstaller", "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller", "com.android.vending",
            "com.google.android.permissioncontroller", "com.miui.securitycenter",
            "com.coloros.safecenter", "com.iqoo.secure"
        )

        private val URL_IDS = listOf(
            "url_bar", "mozac_browser_toolbar_url_view", "location_bar_edit_text", "url_field"
        )

        private val SITES = listOf(
            "facebook.com", "fb.com", "fb.watch", "messenger.com", "instagram.com",
            "tiktok.com", "youtube.com", "youtu.be", "twitter.com", "x.com",
            "snapchat.com", "reddit.com", "web.telegram.org", "discord.com"
        )
    }
}
