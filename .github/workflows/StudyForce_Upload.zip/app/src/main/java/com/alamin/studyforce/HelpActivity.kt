package com.alamin.studyforce

/** A to Z guide to using the app. */
class HelpActivity : Screen() {
    override fun render() {
        header("How it works")
        root.put(
            tv("Everything you need to know, from first setup to the weekly report.", 15f, C.MUTED), 6
        )
        root.put(
            section(
                "1. First setup",
                "On the Home screen, finish the four steps in Finish setup: Show over other apps, Notification access, " +
                    "Device admin and Accessibility service. The Accessibility service is the one that blocks apps."
            ), 16
        )
        root.put(
            section(
                "2. Choose apps to block",
                "Open Apps to block and switch on every app that distracts you: Facebook, games, TikTok, YouTube and so on. " +
                    "Phone, Messages, Contacts, Clock and Calculator are never blocked. " +
                    "You can add all social media apps or all games with one tap."
            ), 12
        )
        root.put(
            section(
                "3. Start a focus session",
                "Pick a time (15 min, 30 min, 1 h, 2 h or your own) and tap Start focus. " +
                    "The chosen apps cannot open, their notifications are hidden, and blocked websites are stopped in browsers. " +
                    "You can add 15 or 30 minutes later, but you can never take time away."
            ), 12
        )
        root.put(
            section(
                "4. Earn break time",
                "Every 60 minutes of study earns 10 minutes of break. During a session you can spend 10 earned minutes " +
                    "to pause the blocking for 10 minutes. Study time is not counted while on a break."
            ), 12
        )
        root.put(
            section(
                "5. Ending early",
                "Tap End early, choose a reason and wait 10 minutes. After the wait you can confirm. " +
                    "The wait is there so you stop and think before giving up."
            ), 12
        )
        root.put(
            section(
                "6. Night lock",
                "You choose when it locks and when it opens. Nothing locks on its own. " +
                    "While it is on, every app except Phone, Messages, Contacts, Clock and Calculator is blocked."
            ), 12
        )
        root.put(
            section(
                "7. Weekly report",
                "See your last 7 days of study time as a picture and share it with a friend, a teacher or your family."
            ), 12
        )
        root.put(
            section(
                "8. Emergency and the admin password",
                "If you must unlock your phone, use Emergency unlock and the admin password from the developer. " +
                    "The same password is needed to uninstall, force stop or turn off the protections of Study Force."
            ), 12
        )
    }
}
