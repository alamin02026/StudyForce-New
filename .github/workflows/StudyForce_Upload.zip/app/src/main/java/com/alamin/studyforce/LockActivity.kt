package com.alamin.studyforce

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout

/** The screen shown on top of a blocked app. */
class LockActivity : Screen() {
    private val h = Handler(Looper.getMainLooper())
    private var dial: DialView? = null

    private val tick = object : Runnable {
        override fun run() {
            val st = Store(this@LockActivity)
            val rem = endTime(st) - st.now()
            if (rem <= 0) {
                goHome()
                finish()
                return
            }
            dial?.set(rem.toFloat() / totalMs(st), titleText(), fmtDur(rem), subText(st))
            h.postDelayed(this, 1000)
        }
    }

    private fun mode() = intent.getStringExtra("mode") ?: "focus"

    private fun endTime(st: Store): Long =
        if (mode() == "night") st.nightWindowEnd() else st.sessionEnd

    private fun totalMs(st: Store): Float {
        val ms = if (mode() == "night") {
            ((st.nightEnd - st.nightStart + 1440) % 1440) * 60_000L
        } else {
            st.sessionEnd - st.sessionStart
        }
        return maxOf(1L, ms).toFloat()
    }

    private fun titleText() = if (mode() == "night") "Night lock ends in" else "Focus ends in"

    private fun subText(st: Store) = "at ${fmtClock(endTime(st))}"

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        redraw()
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    override fun render() {
        val st = Store(this)
        st.finalizeIfDone()
        val t = st.now()
        val night = mode() == "night"
        val active = if (night) st.nightActive(t) else (st.sessionActive(t) && !st.onBreak(t))
        if (!active) {
            goHome()
            finish()
            return
        }
        val label = intent.getStringExtra("label") ?: "This app"

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        root.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        root.put(tv("Blocked", 34f, C.TEXT, true), 14)
        root.put(
            tv(
                if (night) "$label is blocked during your night lock. Only calls and messages work."
                else "$label is blocked during your focus session.",
                16f, C.MUTED
            ), 4
        )

        val d = DialView(this)
        dial = d
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(20)
        root.addView(d, lp)
        val rem = endTime(st) - t
        d.set(rem.toFloat() / totalMs(st), titleText(), fmtDur(rem), subText(st))

        val quote = box()
        quote.put(cap("Remember"), 0)
        quote.put(tv(QUOTES.random(), 16f, C.TEXT), 6)
        root.put(quote, 20)

        root.put(btn("Back to home screen") { goHome(); finish() }, 20)

        if (!night && st.earned >= 10) {
            root.put(btn("Take a 10-min break (uses 10 earned min)", false) {
                st.takeBreak()
                goHome()
                finish()
            }, 10)
        }
        root.put(btn("Emergency unlock (admin password)", false) {
            startActivity(Intent(this, PasswordGateActivity::class.java).putExtra("purpose", "UNLOCK"))
        }, 10)

        h.removeCallbacks(tick)
        h.postDelayed(tick, 1000)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
        finish()
    }

    companion object {
        private val QUOTES = listOf(
            "Small steps every day become big results.",
            "Your phone will still be there later. Your exam will not wait.",
            "Focus now. Relax later.",
            "One hour of real focus beats three hours of distraction.",
            "Future you is watching. Make them proud.",
            "You chose this timer for a reason. Keep going.",
            "Every minute you study now is one less minute of worry before the exam."
        )
    }
}
