package com.alamin.studyforce

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch

/** Lists every app on the phone so the student can choose what to block. */
class AppsActivity : Screen() {

    override fun render() {
        header("Apps to block")
        val st = Store(this)
        val sessionOn = st.sessionActive()
        val chosen = st.blocked.toMutableSet()
        val pm = packageManager

        root.put(
            tv(
                if (sessionOn) "A focus session is running. You can add apps but not remove the ones already chosen."
                else "Pick the apps to block during focus time. WhatsApp is not blocked unless you choose it.",
                14f, C.MUTED
            ), 4
        )

        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        root.put(
            hrow(
                btn("Add social media", false, 14f) {
                    apps.filter { Policy.isSocial(it.packageName) }.forEach { chosen += it.packageName }
                    st.blocked = chosen
                    redraw()
                },
                btn("Add games", false, 14f) {
                    apps.filter { it.category == ApplicationInfo.CATEGORY_GAME }.forEach { chosen += it.packageName }
                    st.blocked = chosen
                    redraw()
                }
            ), 14
        )

        // website blocking switch
        val siteRow = LinearLayout(this)
        siteRow.gravity = Gravity.CENTER_VERTICAL
        siteRow.addView(
            tv("Also block social websites in browsers", 15f, C.TEXT),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        val siteSw = Switch(this)
        siteSw.isChecked = st.blockSites
        siteSw.isEnabled = !(sessionOn && st.blockSites)
        siteSw.setOnCheckedChangeListener { _, on -> st.blockSites = on }
        siteRow.addView(siteSw)
        root.put(siteRow, 14)

        root.put(tv("${chosen.size} selected", 13f, C.YELLOW, true), 14)

        val list = box()
        for ((index, ai) in apps.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))

            val icon = ImageView(this)
            icon.setImageDrawable(pm.getApplicationIcon(ai))
            row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))

            val name = tv(pm.getApplicationLabel(ai).toString(), 16f, C.TEXT)
            name.setPadding(dp(12), 0, dp(8), 0)
            row.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val pkg = ai.packageName
            val sw = Switch(this)
            val wasChosen = pkg in chosen
            sw.isChecked = wasChosen
            sw.isEnabled = !(sessionOn && wasChosen)
            sw.setOnCheckedChangeListener { _, on ->
                if (on) chosen += pkg else chosen -= pkg
                st.blocked = chosen
            }
            row.addView(sw)
            list.addView(row)
            if (index < apps.size - 1) {
                val line = android.view.View(this)
                line.setBackgroundColor(C.LINE)
                list.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
            }
        }
        root.put(list, 8)
    }
}
