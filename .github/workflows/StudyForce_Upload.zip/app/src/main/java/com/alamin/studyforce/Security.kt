package com.alamin.studyforce

import java.security.MessageDigest

/** App-wide constants. */
object AppInfo {
    const val DEVELOPER = "Al Amin"
    const val INSTITUTE = "Student of Civil Technology, Chattogram Polytechnic Institute"
    const val WHATSAPP = "https://wa.me/message/UIDIOULKRUXMI1?src=qr"
}

/**
 * The admin password is NOT stored in the app. Only its SHA-256 hash is.
 *
 * To change the password, run this on your computer (replace NEWPASSWORD):
 *     printf '%s' 'StudyForce::v1::NEWPASSWORD' | sha256sum
 * then paste the 64-character result into HASH below and rebuild the app.
 */
object Security {
    private const val HASH = "3bac182a255d49feba88114ce7c90dd754a3dd8bf622de174b98eab20ca3602b"

    fun check(input: String): Boolean =
        sha256("StudyForce::v1::" + input.trim()) == HASH

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
