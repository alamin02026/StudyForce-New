package com.alamin.studyforce

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Permissions, protection status and the note about the admin password. */
class SettingsActivity : Screen() {

    private fun grace() {
        val st = Store(this)
        st.protectOffUntil = st.now() + 5 * 60_000L
    }

    private fun permissionRow(card: android.widget.LinearLayout, title: String, on: Boolean, open: () -> Unit) {
        if (on) {
            card.put(tv("✓  $title is on", 15f, C.TEXT), 10)
        } else {
            card.put(tv("✗  $title is off", 15f, C.DANGER, true), 12)
            card.put(btn("Open settings", false, 14f) { grace(); open() }, 6)
        }
    }

    override fun render() {
        header("Settings")
        val st = Store(this)
        val t = st.now()

        // permissions
        val perms = box()
        perms.put(cap("Permissions"), 0)
        permissionRow(perms, "Show over other apps", Perms.overlay(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permissionRow(perms, "Notification access", Perms.notifications(this)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        permissionRow(perms, "Device admin", Perms.admin(this)) {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            startActivity(i)
        }
        permissionRow(perms, "Accessibility service", Perms.accessibility(this)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.put(perms, 16)

        // protection state
        val prot = box()
        prot.put(cap("Protection"), 0)
        if (t < st.protectOffUntil) {
            prot.put(
                tv("Protection is paused until ${fmtClock(st.protectOffUntil)} because the admin password was used.", 15f, C.YELLOW),
                6
            )
            prot.put(btn("Turn protection back on now") {
                st.protectOffUntil = 0L
                redraw()
            }, 10)
        } else {
            prot.put(
                tv(
                    "Protection is on. Opening the uninstall, force stop, accessibility or device admin screens " +
                        "for Study Force asks for the admin password.",
                    15f, C.TEXT
                ), 6
            )
        }
        root.put(prot, 12)

        // password note (the password itself is never shown or stored in the app)
        val pw = box()
        pw.put(cap("Admin password"), 0)
        pw.put(
            tv(
                "One admin password, given by the developer, is the master key. In an emergency it can:",
                15f, C.TEXT
            ), 6
        )
        pw.put(
            tv(
                "•  end a focus session or the night lock (Emergency unlock)\n" +
                    "•  allow Study Force to be uninstalled\n" +
                    "•  allow Device admin, Accessibility or Notification access to be turned off\n" +
                    "•  allow Study Force to be force-stopped",
                15f, C.MUTED
            ), 8
        )
        pw.put(
            tv(
                "The same password works on every phone. Keep it private. Without it none of these can be done. " +
                    "After 5 wrong tries the app waits 30 minutes before accepting another try.",
                14f, C.MUTED
            ), 10
        )
        pw.put(btn("Need the password? Message the developer", false, 14f) { openUrl(AppInfo.WHATSAPP) }, 12)
        root.put(pw, 12)

        // phone tips
        root.put(
            section(
                "If a switch is greyed out",
                "On Android 13 or newer: Settings > Apps > Study Force > three dots (top right) > Allow restricted settings. " +
                    "Then turn the permission on again."
            ), 12
        )
        root.put(
            section(
                "Keep it running",
                "On Xiaomi, Oppo, Vivo and Realme phones: allow Autostart for Study Force and set battery usage to " +
                    "No restrictions. Otherwise the phone may stop the blocker in the background."
            ), 12
        )
    }
}
