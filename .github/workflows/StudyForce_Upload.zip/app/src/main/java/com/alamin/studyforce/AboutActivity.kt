package com.alamin.studyforce

import android.widget.ImageView
import android.widget.LinearLayout

class AboutActivity : Screen() {
    override fun render() {
        header("About")

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        root.put(logo, 8)
        (logo.layoutParams as LinearLayout.LayoutParams).apply {
            width = dp(72)
            height = dp(72)
        }

        root.put(tv("Study Force", 30f, C.TEXT, true), 12)
        root.put(tv("Version 1.0", 14f, C.MUTED), 2)
        root.put(
            tv(
                "Study Force helps students stay away from distractions. You set a timer, the apps you chose are " +
                    "blocked until it ends, and your phone stays ready for calls and messages.",
                16f, C.TEXT
            ), 16
        )

        val dev = box()
        dev.put(cap("Developer"), 0)
        dev.put(tv(AppInfo.DEVELOPER, 20f, C.TEXT, true), 6)
        dev.put(tv(AppInfo.INSTITUTE, 15f, C.MUTED), 2)
        dev.put(btn("Contact on WhatsApp") { openUrl(AppInfo.WHATSAPP) }, 14)
        root.put(dev, 20)

        root.put(
            section(
                "What it does",
                "•  Blocks any apps you choose while a timer runs\n" +
                    "•  Hides notifications from blocked apps\n" +
                    "•  Blocks social websites in common browsers\n" +
                    "•  Night lock with times you choose\n" +
                    "•  Earn break time by studying\n" +
                    "•  Weekly report card you can share\n" +
                    "•  Protected by an admin password"
            ), 12
        )

        root.put(
            section(
                "Why it asks for permissions",
                "Accessibility service: to see which app is open and block it.\n" +
                    "Notification access: to hide notifications from blocked apps.\n" +
                    "Show over other apps: to show the lock screen on top of a blocked app.\n" +
                    "Device admin: to stop Study Force from being removed without the admin password."
            ), 12
        )

        root.put(
            section(
                "Privacy policy",
                "Study Force works fully offline and has no internet permission. It does not collect, upload or share " +
                    "any information. It does not read your messages, passwords, photos or what you type. " +
                    "The accessibility service only checks the name of the app on screen and, in browsers, the website address, " +
                    "and only to block what you chose. Your timer, chosen apps and study records stay on this phone and are " +
                    "deleted when you uninstall the app."
            ), 12
        )

        root.put(
            section(
                "Limits to know",
                "A phone restart in Safe Mode or a factory reset can remove any app. Some phone makers use different " +
                    "settings screens, so protection may differ a little on them."
            ), 12
        )

        val help = box()
        help.put(cap("Support and contact"), 0)
        help.put(tv("Need the admin password, found a problem, or have an idea? Message the developer.", 15f, C.TEXT), 6)
        help.put(btn("Message on WhatsApp") { openUrl(AppInfo.WHATSAPP) }, 12)
        root.put(help, 12)

        root.put(tv("Made by ${AppInfo.DEVELOPER}", 12f, C.MUTED), 20)
    }
}
