package com.alamin.studyforce

import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager

/** Decides what is blocked right now. */
object Policy {

    /** Apps that must always stay usable: this app, home screen, phone, messages, keyboard, clock, calculator. */
    fun allowedPackages(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val out = HashSet<String>()
        out += ctx.packageName
        out += listOf(
            "android", "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.incallui"
        )

        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.queryIntentActivities(home, 0).forEach { out += it.activityInfo.packageName }

        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.defaultDialerPackage?.let { out += it }
        } catch (_: Exception) {
        }
        try {
            Telephony.Sms.getDefaultSmsPackage(ctx)?.let { out += it }
        } catch (_: Exception) {
        }
        try {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { out += it.packageName }
        } catch (_: Exception) {
        }

        val keywords = listOf(
            "dialer", "contacts", "calculator", "clock", "incallui",
            "telecom", "emergency", "mms", "messaging"
        )
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(launcher, 0).forEach {
            val p = it.activityInfo.packageName
            if (keywords.any { k -> p.contains(k, ignoreCase = true) }) out += p
        }
        return out
    }

    fun isBlockedNow(st: Store, pkg: String, allowed: Set<String>, t: Long = System.currentTimeMillis()): Boolean {
        if (pkg in allowed) return false
        if (st.nightActive(t)) return true
        return st.sessionActive(t) && !st.onBreak(t) && pkg in st.blocked
    }

    private val SOCIAL = setOf(
        "com.facebook.katana", "com.facebook.lite", "com.facebook.orca", "com.facebook.mlite",
        "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.twitter.android", "org.telegram.messenger",
        "com.snapchat.android", "com.discord", "com.pinterest", "com.reddit.frontpage",
        "com.imo.android.imoim", "com.linkedin.android"
    )

    fun isSocial(pkg: String) = pkg in SOCIAL
}
