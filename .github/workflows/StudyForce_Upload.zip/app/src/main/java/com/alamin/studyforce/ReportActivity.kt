package com.alamin.studyforce

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.widget.ImageView
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Weekly report card: shows the last 7 days and can share the picture (for example on WhatsApp). */
class ReportActivity : Screen() {

    override fun render() {
        header("Weekly report card")
        val st = Store(this)
        val bmp = makeBitmap(st)

        val img = ImageView(this)
        img.setImageBitmap(bmp)
        img.adjustViewBounds = true
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        root.put(img, 12)

        root.put(btn("Share report card") { share(bmp) }, 16)
        root.put(tv("The picture is made on your phone. You choose who receives it.", 13f, C.MUTED), 8)
    }

    private fun share(bmp: Bitmap) {
        try {
            val dir = File(cacheDir, "reports")
            dir.mkdirs()
            val f = File(dir, "study_force_report.png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = "image/png"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share report card"))
        } catch (_: Exception) {
            toast("Could not share the report.")
        }
    }

    private fun makeBitmap(st: Store): Bitmap {
        val w = 1080
        val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(C.BG)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        p.color = C.YELLOW
        p.textSize = 72f
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("Study Force", 70f, 130f, p)
        p.color = C.MUTED
        p.textSize = 38f
        p.typeface = Typeface.DEFAULT
        c.drawText("Weekly report card", 70f, 195f, p)

        val mins = IntArray(7) { st.studyOn(6 - it) }
        val attempts = (0..6).sumOf { st.attemptsOn(it) }
        val total = mins.sum()
        val maxV = mins.maxOrNull() ?: 0
        val activeDays = mins.count { it > 0 }

        val days = Array(7) { i ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -(6 - i))
            SimpleDateFormat("EEE", Locale.ENGLISH).format(cal.time)
        }
        val bestDay = if (maxV > 0) days[mins.indexOf(maxV)] else "-"

        // summary
        p.color = C.TEXT
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = 96f
        c.drawText(fmtMins(total), 70f, 340f, p)
        p.color = C.MUTED
        p.typeface = Typeface.DEFAULT
        p.textSize = 36f
        c.drawText("studied in the last 7 days", 70f, 392f, p)

        p.color = C.TEXT
        p.textSize = 40f
        c.drawText("Best day: $bestDay", 70f, 480f, p)
        c.drawText("Days studied: $activeDays of 7", 70f, 540f, p)
        c.drawText("Tried to open blocked apps: $attempts times", 70f, 600f, p)

        // bars
        val left = 70f
        val baseY = 1120f
        val maxH = 380f
        val barW = 100f
        val gap = (940f - 7 * barW) / 6f
        for (i in 0..6) {
            val x = left + i * (barW + gap)
            val bh = if (maxV == 0) 0f else mins[i] * maxH / maxV
            p.color = 0x22EAF1FA
            c.drawRect(x, baseY - maxH, x + barW, baseY, p)
            p.color = C.YELLOW
            c.drawRect(x, baseY - bh, x + barW, baseY, p)
            p.color = C.TEXT
            p.textSize = 28f
            p.textAlign = Paint.Align.CENTER
            if (mins[i] > 0) c.drawText(fmtMins(mins[i]), x + barW / 2, baseY - bh - 14f, p)
            p.color = C.MUTED
            p.textSize = 30f
            c.drawText(days[i], x + barW / 2, baseY + 50f, p)
            p.textAlign = Paint.Align.LEFT
        }

        p.color = C.MUTED
        p.textSize = 28f
        c.drawText("Made with Study Force  |  Developer: ${AppInfo.DEVELOPER}", 70f, 1280f, p)
        return bmp
    }
}
