package com.alamin.studyforce

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Removes notifications from apps that are blocked right now. */
class NotifService : NotificationListenerService() {
    private var allowed: Set<String> = emptySet()
    private var allowedAt = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val st = Store(this)
        val t = st.now()
        if (allowed.isEmpty() || t - allowedAt > 60_000) {
            allowed = Policy.allowedPackages(this)
            allowedAt = t
        }
        if (Policy.isBlockedNow(st, pkg, allowed, t)) {
            try {
                cancelNotification(sbn.key)
            } catch (_: Exception) {
            }
        }
    }
}
