package com.alamin.studyforce

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object C {
    val BG = 0xFF0D2745.toInt()
    val BG_TOP = 0xFF123B66.toInt()
    val BG_BOT = 0xFF081B31.toInt()
    val CARD = 0xFF133559.toInt()
    val CARD_TOP = 0xFF1A426F.toInt()
    val LINE = 0x33EAF1FA
    val TEXT = 0xFFEAF1FA.toInt()
    val MUTED = 0xFF9DB4CF.toInt()
    val YELLOW = 0xFFFFC22E.toInt()
    val YELLOW_LIGHT = 0xFFFFD866.toInt()
    val DANGER = 0xFFFF8A80.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

fun Context.tv(text: String, size: Float = 16f, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

/** Small spaced-out label, used above sections. */
fun Context.cap(text: String): TextView {
    val t = tv(text.uppercase(), 12f, C.MUTED, true)
    t.letterSpacing = 0.12f
    return t
}

private fun Context.ripple(content: Drawable, radiusDp: Int): RippleDrawable {
    val mask = GradientDrawable()
    mask.cornerRadius = dp(radiusDp).toFloat()
    mask.setColor(Color.WHITE)
    return RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask)
}

fun Context.btn(text: String, primary: Boolean = true, size: Float = 16f, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.isAllCaps = false
    b.textSize = size
    b.setTextColor(if (primary) C.BG else C.TEXT)
    b.typeface = if (primary) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    val content = GradientDrawable()
    content.cornerRadius = dp(16).toFloat()
    if (primary) {
        content.orientation = GradientDrawable.Orientation.TOP_BOTTOM
        content.colors = intArrayOf(C.YELLOW_LIGHT, C.YELLOW)
    } else {
        content.setColor(C.CARD)
        content.setStroke(dp(1), C.LINE)
    }
    b.background = ripple(content, 16)
    b.stateListAnimator = null
    b.minHeight = dp(54)
    b.minimumHeight = dp(54)
    b.setOnClickListener { onClick() }
    return b
}

fun Context.box(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(18), dp(16), dp(18), dp(16))
    val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.CARD_TOP, C.CARD))
    bg.cornerRadius = dp(18).toFloat()
    bg.setStroke(dp(1), C.LINE)
    l.background = bg
    return l
}

fun Context.hrow(a: View, b: View): LinearLayout = hrowN(a, b)

/** A row where every child gets the same width. */
fun Context.hrowN(vararg views: View): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    for ((i, v) in views.withIndex()) {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        if (i > 0) lp.leftMargin = dp(8)
        l.addView(v, lp)
    }
    return l
}

/** A small box with a big number and a label under it. */
fun Context.statTile(value: String, label: String): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.gravity = Gravity.CENTER
    l.setPadding(dp(8), dp(14), dp(8), dp(14))
    val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.CARD_TOP, C.CARD))
    bg.cornerRadius = dp(16).toFloat()
    bg.setStroke(dp(1), C.LINE)
    l.background = bg
    val v = tv(value, 22f, C.YELLOW, true)
    v.gravity = Gravity.CENTER
    val lb = tv(label, 12f, C.MUTED)
    lb.gravity = Gravity.CENTER
    l.addView(v)
    l.addView(lb)
    return l
}

/** A tappable tile with an icon and a name (used for the menu on Home). */
fun Context.navTile(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.gravity = Gravity.CENTER
    l.setPadding(dp(8), dp(16), dp(8), dp(16))
    l.minimumHeight = dp(96)
    val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.CARD_TOP, C.CARD))
    bg.cornerRadius = dp(18).toFloat()
    bg.setStroke(dp(1), C.LINE)
    l.background = ripple(bg, 18)
    val img = ImageView(this)
    img.setImageResource(icon)
    img.setColorFilter(C.YELLOW)
    l.addView(img, LinearLayout.LayoutParams(dp(30), dp(30)))
    val t = tv(label, 14f, C.TEXT)
    t.gravity = Gravity.CENTER
    t.setPadding(0, dp(8), 0, 0)
    l.addView(t)
    l.isClickable = true
    l.setOnClickListener { onClick() }
    return l
}

/** A card with a small title and a paragraph of text. */
fun Context.section(title: String, body: String): LinearLayout {
    val b = box()
    b.put(cap(title), 0)
    b.put(tv(body, 15f, C.TEXT), 6)
    return b
}

/** Adds a child to a vertical layout, full width, with space above it (in dp). */
fun ViewGroup.put(v: View, top: Int = 12): View {
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = (top * resources.displayMetrics.density).toInt()
    addView(v, lp)
    return v
}

fun Context.goHome() {
    val i = Intent(Intent.ACTION_MAIN)
    i.addCategory(Intent.CATEGORY_HOME)
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(i)
}

fun Context.openUrl(url: String) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        toast("Could not open the link.")
    }
}

fun fmtDur(ms: Long): String {
    val s = maxOf(0L, ms) / 1000
    return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

fun fmtClock(t: Long): String = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(t))

fun fmtMin(m: Int): String {
    val h12 = if ((m / 60) % 12 == 0) 12 else (m / 60) % 12
    return "%02d:%02d %s".format(h12, m % 60, if (m / 60 < 12) "AM" else "PM")
}

fun fmtMins(m: Int): String = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"

/** Checks which permissions the user has already switched on. */
object Perms {
    fun accessibility(ctx: Context): Boolean {
        val s = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.split(':').any { it.startsWith(ctx.packageName) && it.endsWith("BlockerService") }
    }

    fun notifications(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun overlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun admin(ctx: Context): Boolean {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(ctx, AdminReceiver::class.java))
    }

    fun all(ctx: Context) = accessibility(ctx) && notifications(ctx) && overlay(ctx) && admin(ctx)
}

/** Dark blue background with a soft gradient and a faint engineering-paper grid. */
class GridBackground(private val step: Float) : Drawable() {
    private val fill = Paint()
    private val line = Paint()

    init {
        line.color = 0x0DEAF1FA
        line.strokeWidth = 1f
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        fill.shader = LinearGradient(
            0f, 0f, 0f, bounds.height().toFloat(), C.BG_TOP, C.BG_BOT, Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        val b = bounds
        c.drawRect(b, fill)
        var x = b.left.toFloat()
        while (x <= b.right) {
            c.drawLine(x, b.top.toFloat(), x, b.bottom.toFloat(), line)
            x += step
        }
        var y = b.top.toFloat()
        while (y <= b.bottom) {
            c.drawLine(b.left.toFloat(), y, b.right.toFloat(), y, line)
            y += step
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/** The round timer: tick marks, a yellow progress ring, and three lines of text in the middle. */
class DialView(ctx: Context) : View(ctx) {
    private var fraction = 1f
    private var title = ""
    private var big = ""
    private var sub = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun set(fraction: Float, title: String, big: String, sub: String) {
        this.fraction = fraction.coerceIn(0f, 1f)
        this.title = title
        this.big = big
        this.sub = sub
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val max = (300 * resources.displayMetrics.density).toInt()
        val size = minOf(MeasureSpec.getSize(widthSpec), max)
        setMeasuredDimension(size, size)
    }

    override fun onDraw(c: Canvas) {
        val s = width.toFloat()
        val d = resources.displayMetrics.density
        val cx = s / 2f
        val cy = s / 2f

        // outer circle
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = C.LINE
        c.drawCircle(cx, cy, s / 2f - 2f * d, p)

        // tick marks
        for (i in 0 until 60) {
            val ang = Math.toRadians(i * 6.0 - 90.0)
            val major = i % 5 == 0
            val r1 = s / 2f - 12f * d
            val r2 = r1 - (if (major) 9f else 5f) * d
            p.strokeWidth = (if (major) 2f else 1f) * d
            p.color = if (major) 0x99EAF1FA.toInt() else 0x40EAF1FA
            val ca = Math.cos(ang).toFloat()
            val sa = Math.sin(ang).toFloat()
            c.drawLine(cx + r1 * ca, cy + r1 * sa, cx + r2 * ca, cy + r2 * sa, p)
        }

        // ring track and progress
        val r = s / 2f - 40f * d
        rect.set(cx - r, cy - r, cx + r, cy + r)
        p.strokeWidth = 12f * d
        p.strokeCap = Paint.Cap.BUTT
        p.color = 0x1AEAF1FA
        c.drawArc(rect, 0f, 360f, false, p)
        if (fraction > 0f) {
            p.strokeCap = Paint.Cap.ROUND
            p.color = C.YELLOW
            c.drawArc(rect, -90f, 360f * fraction, false, p)
        }

        // text in the middle
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.color = C.MUTED
        p.typeface = Typeface.DEFAULT
        p.textSize = s * 0.052f
        c.drawText(title, cx, cy - s * 0.15f, p)
        p.color = C.TEXT
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = s * 0.135f
        c.drawText(big, cx, cy + s * 0.05f, p)
        p.color = C.MUTED
        p.typeface = Typeface.DEFAULT
        p.textSize = s * 0.048f
        c.drawText(sub, cx, cy + s * 0.16f, p)
    }
}

/** Base screen: gradient background, scrolling column, rebuilt every time the screen comes back. */
abstract class Screen : Activity() {
    lateinit var root: LinearLayout

    abstract fun render()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C.BG_TOP
        window.navigationBarColor = C.BG_BOT
        val sv = ScrollView(this)
        sv.background = GridBackground(dp(24).toFloat())
        sv.isFillViewport = true
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(44), dp(20), dp(32))
        sv.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        root.removeAllViews()
        render()
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(220).start()
    }

    fun redraw() {
        root.removeAllViews()
        render()
    }

    fun header(title: String) {
        val back = tv("‹ Back", 16f, C.MUTED)
        back.setPadding(0, dp(4), dp(16), dp(12))
        back.gravity = Gravity.START
        back.setOnClickListener { finish() }
        root.addView(back)
        root.put(tv(title, 28f, C.TEXT, true), 0)
    }
}
