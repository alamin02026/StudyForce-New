package com.alamin.studyforce

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.widget.EditText
import android.widget.TextView

/** Asks for the admin password. Used for emergency unlock and for uninstall / deactivate attempts. */
class PasswordGateActivity : Screen() {

    override fun render() {
        val st = Store(this)
        val uninstall = (intent.getStringExtra("purpose") ?: "UNLOCK") == "UNINSTALL"

        root.put(
            tv(if (uninstall) "Protected by Study Force" else "Emergency unlock", 26f, C.TEXT, true), 8
        )
        root.put(
            tv(
                if (uninstall) "Removing, stopping or changing Study Force needs the admin password."
                else "Enter the admin password to end the current lock.",
                15f, C.MUTED
            ), 8
        )

        if (st.lockedOut()) {
            val mins = maxOf(1L, (st.lockoutUntil - st.now()) / 60_000L)
            root.put(tv("Too many wrong tries. Try again in about $mins minutes.", 15f, C.DANGER), 20)
        } else {
            val et = EditText(this)
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            et.hint = "Admin password"
            et.setTextColor(C.TEXT)
            et.setHintTextColor(C.MUTED)
            et.setPadding(dp(16), dp(12), dp(16), dp(12))
            val bg = GradientDrawable()
            bg.cornerRadius = dp(14).toFloat()
            bg.setColor(C.CARD)
            bg.setStroke(dp(1), C.LINE)
            et.background = bg
            root.put(et, 20)

            val msg: TextView = tv("", 14f, C.DANGER)
            root.put(msg, 8)

            root.put(btn("Unlock") {
                if (Security.check(et.text.toString())) {
                    st.failCount = 0
                    if (uninstall) {
                        st.protectOffUntil = st.now() + 10 * 60_000L
                        toast("Protection paused for 10 minutes. Open the screen again now.")
                    } else {
                        st.emergencyUnlock()
                        toast("Unlocked.")
                    }
                    finish()
                } else {
                    st.registerFail()
                    if (st.lockedOut()) {
                        redraw()
                    } else {
                        msg.text = "Wrong password."
                    }
                }
            }, 8)
        }

        root.put(btn("Need the password? Message the developer on WhatsApp", false) {
            openUrl(AppInfo.WHATSAPP)
        }, 12)
        root.put(btn("Cancel", false) { cancel() }, 8)
    }

    private fun cancel() {
        val uninstall = (intent.getStringExtra("purpose") ?: "UNLOCK") == "UNINSTALL"
        if (uninstall) goHome()
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        cancel()
    }
}
