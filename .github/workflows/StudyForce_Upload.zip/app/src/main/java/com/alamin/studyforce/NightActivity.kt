package com.alamin.studyforce

import android.app.TimePickerDialog
import android.widget.LinearLayout
import android.widget.Switch

/** Night lock: the student chooses when it starts and ends. Nothing locks on its own. */
class NightActivity : Screen() {
    override fun render() {
        header("Night lock")
        val st = Store(this)
        val t = st.now()
        val active = st.nightActive(t)

        root.put(
            tv(
                "Choose the hours you want your phone locked. While it is on, every app is blocked " +
                    "except Phone, Messages, Contacts, Clock and Calculator.",
                15f, C.MUTED
            ), 6
        )

        if (active) {
            root.put(
                tv(
                    "Night lock is active now. It cannot be changed until ${fmtClock(st.nightWindowEnd(t))}.",
                    15f, C.YELLOW, true
                ), 16
            )
        }

        val card = box()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val label = tv("Night lock", 18f, C.TEXT, true)
        row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = st.nightOn
        sw.isEnabled = !active
        sw.setOnCheckedChangeListener { _, on ->
            st.nightOn = on
            redraw()
        }
        row.addView(sw)
        card.put(row, 0)
        root.put(card, 16)

        val startBtn = btn("Locks at  ${fmtMin(st.nightStart)}", false) {
            TimePickerDialog(this, { _, h, m ->
                st.nightStart = h * 60 + m
                redraw()
            }, st.nightStart / 60, st.nightStart % 60, false).show()
        }
        val endBtn = btn("Opens at  ${fmtMin(st.nightEnd)}", false) {
            TimePickerDialog(this, { _, h, m ->
                st.nightEnd = h * 60 + m
                redraw()
            }, st.nightEnd / 60, st.nightEnd % 60, false).show()
        }
        startBtn.isEnabled = !active
        endBtn.isEnabled = !active
        startBtn.alpha = if (active) 0.45f else 1f
        endBtn.alpha = if (active) 0.45f else 1f
        root.put(startBtn, 12)
        root.put(endBtn, 8)

        root.put(
            tv(
                "Turned the wrong time on by mistake? Use Emergency unlock with the admin password on the home screen.",
                13f, C.MUTED
            ), 16
        )
    }
}
