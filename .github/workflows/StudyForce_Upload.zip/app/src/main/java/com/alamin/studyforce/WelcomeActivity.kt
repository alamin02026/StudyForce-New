package com.alamin.studyforce

import android.content.Intent
import android.widget.ImageView
import android.widget.LinearLayout

/** Shown every time the app is opened from its icon. "Get started" goes to Home. */
class WelcomeActivity : Screen() {

    override fun render() {
        val st = Store(this)
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        root.addView(logo, LinearLayout.LayoutParams(dp(96), dp(96)))

        root.put(tv("Welcome to", 18f, C.MUTED), 24)
        root.put(tv("Study Force", 40f, C.YELLOW, true), 2)
        root.put(tv("Block distractions. Study with focus.", 16f, C.TEXT), 8)

        val dev = box()
        dev.put(tv("Developed by", 13f, C.MUTED), 0)
        dev.put(tv(AppInfo.DEVELOPER, 22f, C.TEXT, true), 2)
        dev.put(tv(AppInfo.INSTITUTE, 15f, C.MUTED), 2)
        root.put(dev, 28)

        root.put(btn("Contact developer on WhatsApp", false) { openUrl(AppInfo.WHATSAPP) }, 14)
        root.put(btn("Get started") {
            st.welcomed = true
            openMain()
        }, 10)
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
