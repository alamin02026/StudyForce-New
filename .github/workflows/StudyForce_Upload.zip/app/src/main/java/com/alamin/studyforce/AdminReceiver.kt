package com.alamin.studyforce

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** While this is an active device admin, Android refuses to uninstall the app. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Study Force protection will be switched off. This needs the admin password."
}
